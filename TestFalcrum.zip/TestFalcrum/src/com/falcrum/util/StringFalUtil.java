package com.falcrum.util;

import org.apache.log4j.Logger;


/**
 * 
 * @author Ravi Thapa
 *
 */


public class StringFalUtil {

	private static final Logger logger = Logger.getLogger(StringFalUtil.class);

	/**
	 * This method will take String as input and return first char + number of unique chars between first and last + last
	 * Smooth would become S3h
	 * @param inputStr
	 * @return
	 * @throws Exception 
	 */

	public String firstCountUniqueLast(String inputStr) throws Exception {
		int count = 0;
		String str = "";
		String first = "";
		String last = "";
		logger.info("String length : "+inputStr.length());

		if(inputStr.length() > 3){
			try{
				first = String.valueOf(inputStr.charAt(0));
				last = String.valueOf(inputStr.charAt(inputStr.length() - 1));
				logger.info("String first : "+first);
				logger.info("String last : "+last);
				for(int i = 1; i < inputStr.length() - 1; i++) {
					if(!str.contains(String.valueOf(inputStr.charAt(i)))) {
						str += String.valueOf(inputStr.charAt(i));
						count++;
					}
				}
			}catch(NullPointerException npe){
				logger.error("Null value found in firstCountUniqueLast : " + npe);
				throw new Exception("Null value found in firstCountUniqueLast : " + npe);
			}catch(ArrayIndexOutOfBoundsException aiobe){
				logger.error("Array index is less than condtion in iteration : " + aiobe);
				throw new IndexOutOfBoundsException("Array index is less than condtion in iteration.");
			}
		}else{
			logger.info("String length should be 3 or greater than three to evaluate it. String Length : " + inputStr.length());
		}
		logger.info("Final String is : " + first + count + last);
		return first + count + last;
	}//end of 
}//end of the class
