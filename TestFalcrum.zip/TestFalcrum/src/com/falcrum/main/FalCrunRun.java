package com.falcrum.main;

import org.apache.log4j.Logger;

import com.falcrum.util.StringFalUtil;

/**
 * 
 * @author Ravi Thapa
 *
 */
public class FalCrunRun {

	private static final Logger logger = Logger.getLogger(FalCrunRun.class);
	public static StringFalUtil sfu = null;

	public static void main(String[] s){
		sfu = new StringFalUtil();
		try {
			System.out.println("Result of Input String \"Smooth\" is : "+sfu.firstCountUniqueLast("Smooth"));
		} catch (Exception e) {
			logger.error("Exception in running program for reason : "+e);
		}
	}
}//end of the main class
