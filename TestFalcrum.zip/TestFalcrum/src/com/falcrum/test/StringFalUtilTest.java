package com.falcrum.test;

import junit.framework.TestCase;

import org.apache.log4j.Logger;

import com.falcrum.util.StringFalUtil;

/**
 * 
 * @author Ravi Thapa
 *
 */
public class StringFalUtilTest extends TestCase{

	private static final Logger logger = Logger.getLogger(StringFalUtilTest.class);
	StringFalUtil sfu = null;
	String testStr = "Smooth";

	protected void setUp(){
		sfu = new StringFalUtil();
		logger.info("StringFalUtil class in initialized.");
	}

	public void testFirstCountUniqueLast(){	     
		try {
			assertEquals("S3h", sfu.firstCountUniqueLast(testStr));
		} catch (Exception e) {
			logger.info("Exception  in testFirstCountUniqueLast for reason : "+e);
		}
	}

}//end of the test class
